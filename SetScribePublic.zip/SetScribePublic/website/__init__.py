
import os
from dotenv import load_dotenv, find_dotenv
from flask import Flask
from flask_login import LoginManager, UserMixin, login_required
from supabase_py import create_client, Client
from .custom_filters import replace_spaces_with_hyphens




url = "xxxxxxxxxxxxxxxxxxx"
key = "xxxxxxxxxxxxxxxxxxx"

supabase: Client = create_client(url,key)

class User(UserMixin):
    def __init__(self, id, username, email, password):
        self.id = id
        self.username = username
        self.email = email
        self.password = password

    @staticmethod
    def get(id):
        user_data = supabase.table("Users").select("*").eq("id", id).execute()
        user = User(
            username=user_data['data'][0]['username'],
            email=user_data['data'][0]['email'],
            password=user_data['data'][0]['password'],
            id=user_data['data'][0]['id']
        )
        return user
    
def create_app():
    app = Flask(__name__)

    app.jinja_env.filters['replace_spaces_with_hyphens'] = replace_spaces_with_hyphens
    
    app.config['SECRET_KEY'] = 'xxxxxxxxxxxxxxxxxxxxxxx'
    from .views import views
    from .auth import auth
    login_manager = LoginManager()
    login_manager.login_view = "auth.login"
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
    # Query the user by ID from Supabase and create a User object
        user_data = supabase.table("Users").select("*").eq("id", user_id).execute()
        
        user = User(
        id=user_data['data'][0]['id'],
        username=user_data['data'][0]['username'],
        email=user_data['data'][0]['email'],
        password=user_data['data'][0]['password']
    )
        return user

    app.register_blueprint(views, url_prefix='/')
    app.register_blueprint(auth, url_prefix='/auth/')
    
    return app