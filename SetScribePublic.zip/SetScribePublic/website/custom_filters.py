def replace_spaces_with_hyphens(value):
    return value.replace(' ', '-')