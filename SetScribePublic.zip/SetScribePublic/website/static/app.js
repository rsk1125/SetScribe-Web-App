console.log("shitty");
const observer2 = new IntersectionObserver((entries2) => {
   
    entries2.forEach((entry) => {
        console.log(entry)
        if (entry.isIntersecting){
            entry.target.classList.add('show');
        }
    });
    
    });
    
    
    
    const hiddenElements2 = document.querySelectorAll('.hidden');
    hiddenElements2.forEach((el) => observer2.observe(el));