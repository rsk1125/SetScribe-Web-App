function showOverlay() {
  if (window.matchMedia('(max-width: 600px)').matches) {
    console.log("mobile")
  }
  else{
  document.getElementById("overlay").style.display = "block";
  }
}

function hideOverlay() {
  if (window.matchMedia('(max-width: 600px)').matches) {
    console.log("mobile")
  }
  else{
  document.getElementById("overlay").style.display = "none";
  }
}

var overlayTimeout;

function showOverlay() {
  if (window.matchMedia('(max-width: 600px)').matches) {
    console.log("mobile")
  }
  else{
    console.log('Function disabled on mobile');
  clearTimeout(overlayTimeout); // Clear any previous timeout
  document.getElementById("overlay").style.display = "block";
  }
}

function hideOverlay() {
  if (window.matchMedia('(max-width: 600px)').matches) {
    console.log("mobile")
  }
  else{
  overlayTimeout = setTimeout(function () {
    document.getElementById("overlay").style.display = "none";
  }, 100); // Adjust the delay time (in milliseconds) as needed
}
}

function refreshAllExercises(folderName) {

  show = folderName.getAttribute('data-form')
  console.log(show)

  show

  var exerciseInfo = $('input[name="exercise"]', folderName).val();
  var weightInfo = $('input[name="weight"]', folderName).val();
  var repInfo = $('input[name="reps"]', folderName).val();

  const POSTdata = {
    exercise: exerciseInfo,
    weight: weightInfo,
    reps: repInfo

}

  $.ajax({
    url: '/addSet',
    method: 'POST',
    data: POSTdata,
    success: function (response) {
      console.log("POST COMPLETE")
    },
    error: function (error) {
      console.error('Error:', error);
    }
  });



  $.ajax({
    url: '/refreshAllExercises',
    method: 'GET',
    data: {data : show},
    success: function (response) {
      // Update the graph section with the received data
      $('.folder-list-item#allExercisesFolder').html(response)
      console.log('.folder-list-item#allExercisesFolder')
      console.log("data is back")
    },
    error: function (error) {
      console.error('Error:', error);
    }
  });
}

function showForm() {
  var addButton = document.querySelector('.add-workout-button');
  addButton.classList.add('hidebutton');

  var formContainer = document.getElementById("form-container");
  var form = document.getElementById("add-form")
  formContainer.classList.add('showform')
  form.classList.add('showform')
}

function setButtonClick(button) {
  button.classList.add("deleted")
  var id = button.id
  console.log(id)
  var exercise = button.dataset.exercise
  console.log(exercise);
  console.log('div[data-form="' + exercise + '"]')
  console.log('div[data-form="' + id + '"][data-exercise="' + exercise + '"]')
  var targetDiv = document.querySelector('div[data-form="' + id + '"][data-exercise="' + exercise + '"]');

  targetDiv.classList.remove("deleted");

}

function setButtonClickAll(button) {
  button.classList.add("deleted")
  var id = button.id
  console.log(id)
  var exercise = button.dataset.exercise
  console.log(exercise);
  console.log('div[data-form="' + exercise + '"]')
  console.log('div[data-form="' + id + '"][data-exercise="' + exercise + '"]')
  var targetDiv = document.querySelector('div[data-exercise="' + exercise + '"]');

  targetDiv.classList.remove("deleted");

}



function showAddForm() {
  var addButton = document.getElementById('addSetButton');
  addButton.classList.add('hidebutton');


  var form = document.getElementById("add-form-container2")

  form.classList.remove('hidebutton')
}



// Get a reference to the submit button
var setSubmitButton = document.getElementById("set-submit-btn-user");

// Add a click event listener to the submit button
setSubmitButton.addEventListener("click", function (event) {
  console.log("hide in progress");

  // Find the nearest parent div with id "add-form-container2" and hide it
  var addFormContainer = setSubmitButton.closest("#add-form-container2");
  if (addFormContainer) {
    addFormContainer.classList.add("hidebutton");
  }

  event.preventDefault(); // Prevent the default form submission
});
function toggleFolderContents(button) {
  var parent = button.parentNode;
  var contents = parent.querySelector(".folder-caret");
  contents.classList.toggle("rotate");

  var folderContents = parent.nextElementSibling;
  folderContents.classList.toggle("hide-folder-contents");
}

function preventDef(event) {
  event.preventDefault();

}
function toggleFolderItemContents(button) {
  var parent = button.parentNode;
  var contents = parent.querySelector(".folder-contents-listed-exercise-caret");
  contents.classList.toggle("rotate");

  var itemContents = parent.nextElementSibling;
  itemContents.classList.toggle("hide-folder-item-contents");
}

function toggleNewFolderInput(button) {
  var parent = button.parentNode;
  var contents = parent.querySelector(".show-new-folder-input");
  contents.classList.toggle("deleted");

}



//function to delete exercise within folder
function deleteExerciseEntry(entryId, button) {
  fetch(`/delete_entry`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ entryId })
  })
    .then(response => {
      if (response.ok) {
        return response.json(); // Parse the JSON response
      } else {
        throw new Error('Error deleting entry.'); // Throw an error for non-OK responses
      }
    })
    .then(data => {
      button.closest('.item-set-details').classList.add('deleted');
      // Entry deleted successfully
      console.log('Entry deleted:', data);
    })
    .catch(error => {
      console.error('Error:', error);
    });
}




function clearInputDialog(button) {
  console.log('poop')
  var id = button.dataset.field
  var temp = button.dataset.exercise
  console.log(id)
  var targetDiv = document.querySelector('div[data-form="' + temp + '"][data-exercise="' + id + '"]');
  var targetButton = document.querySelector('a[data-exercise="' + id + '"][id="' + temp + '"]');

  targetButton.classList.remove('deleted')
  targetDiv.classList.add('deleted')

}

function deleteEntry(entryId, button) {

  var listItem = document.getElementById(entryId);
  console.log(entryId)
  console.log(typeof(entryId))
  var test = JSON.stringify({entryId})
  console.log(typeof(test))
  $.ajax({
    url: '/delete_folder',
    type: 'DELETE',
    contentType: 'text/plain',
    data: entryId,
    success: function () {
      // Entry deleted successfully
      console.log('folder deleted.');
      refreshUserFolderList();
    },
    error: function () {
      // Handle error case
      console.error('Error deleting entry.');
    }
  });
  refreshUserFolderList()
}

//function to initialize analysis data



function clearInputDialogAll(button) {
  console.log('poop')
  var id = button.dataset.field
  var temp = button.dataset.exercise
  console.log(id)
  var targetDiv = document.querySelector('div[data-exercise="' + id + '"]');
  var targetButton = document.querySelector('a[data-exercise="' + id + '"]');

  targetButton.classList.remove('deleted')
  targetDiv.classList.add('deleted')

}

function clearFolderDialog(button) {
  div = button.parentNode;
  div.classList.toggle('deleted')
}

function refreshUserFolderList() {

  $.ajax({
    url: '/refreshUserFolderList',
    method: 'GET',
    success: function (response) {
      // Update the graph section with the received data
      $('.UserBeginning').html(response)
      console.log("data is back")
    },
    error: function (error) {
      console.error('Error:', error);
    }
  });
}

//function to delete a user folder


