from flask import Blueprint, render_template, request, jsonify, session, flash, get_flashed_messages
from json.decoder import JSONDecodeError
from flask_login import login_required, current_user
from website import url, key
from supabase_py import create_client, Client
from datetime import datetime


import time
views = Blueprint('views', __name__)
supabase: Client = create_client(url,key)




exercise_names = [
"Full Reverse Crunch",
"Incline Hip Thrust",
"Incline Reverse Crunch",
"Lying Hip Thrust",
"Reverse Crunch",
"Reverse Medicine Ball Crunch",
"Alternating Heel Touch",
"Bent-Knee Medicine Ball Hip Rotation",
"Cable Chop",
"Cross Crunch",
"Cross Crunch w/ Medicine Ball",
"Decline Cross Sit-Up",
"Decline Sit-Up w/ Twist",
"Reverse Cable Chop",
"Seated Medicine Ball Twist",
"Trunk Rotator",
"Ab Cycle",
"Kneeling Ab Rollout",
"Medicine Ball V-Up",
"V-Up",
"Weighted V-Up",
"Bent Knee Sit-Up",
"Bent-Knee Crunch",
"Crunch",
"Crunch",
"Decline Crunch",
"Decline Sit-Up",
"Heel Touch",
"Sit-Up",
"Weighted Crunch",
"Assisted Pull-Up",
"Close-Grip Lat Pulldown",
"Inverted Pull-Up",
"Lat Pulldown",
"Pull-Up",
"Reverse-Grip Lat Pullown",
"Reverse-Grip Pull-Up",
"V-Bar Pull-Up",
"Wide-Grip Lat Pulldown",
"Bent-Over Alternating Dumbbell Row",
"Bent-Over Barbell Row",
"Bent-Over Dumbbell Row",
"Bent-Over Hammer Dumbbell Row",
"Bent-Over Long Barbell Row",
"Bent-Over Reverse-Grip Barbell Row",
"Bent-Over Single-Arm Long Barbell Row",
"Machine Row",
"One Arm Dumbbell Row",
"Reverse Incline Dumbbell Row",
"Rope Cable Row",
"Seated Cable Row",
"Seated Row",
"Single-Arm Cable Row",
"Single-Arm Dumbbell Row",
"Single-Arm Lat Pulldown",
"Standing Cable Row",
"Standing Single-Arm Cable Row",
"Alternating Dumbbell Curl",
"Alternating Hammer Curl",
"Barbell Curl",
"Bicep Curl",
"Cable Curl",
"Concentration Dumbbell Curl",
"Cross Body Hammer Curl",
"Dumbbell Curl",
"EZ-Bar Curl",
"Hammer Curl",
"Incline Alternating Dumbbell Curl",
"Incline Alternating Hammer Curl",
"Incline Dumbbell Curl",
"Incline Hammer Curl",
"Kneeling Cable Curl",
"Lying Cable Curl",
"Lying Double Biceps Cable Curl",
"Lying High Cable Curl",
"Machine Curl",
"Overhead Double Biceps Cable Curl",
"Overhead Rope Cable Curl",
"Preacher Barbell Curl",
"Preacher Cable Curl",
"Preacher Dumbbell Curl",
"Preacher EZ-Bar Curl",
"Preacher Hammer Dumbbell Curl",
"Preacher Single-Arm Dumbbell Curl",
"Reverse Curl",
"Rope Cable Curl",
"Seated Alternating Curl",
"Seated Alternating Hammer Curl",
"Seated Dumbbell Curl",
"Seated Hammer Curl",
"Single-Arm Barbell Curl",
"Single-Arm Cable Curl",
"Spider Curl",
"Barbell Calf Raise",
"Calf Press",
"Calf Raise - Seated",
"Calf Raise - Standing",
"Dumbbell Calf Raise",
"Single-Leg Calf Press",
"Single-Leg Dumbbell Calf Raise",
"Smith Machine Calf Raise",
"Seated Calf Raise",
"Seated Single-Leg Calf Raise",
"Alternating Dumbbell Bench Press",
"Barbell Bench Press",
"Chest Press",
"Decline Dumbbell Bench Press",
"Decline Smith Machine Bench Press",
"Dumbbell Bench Press",
"Dumbbell Push-Up",
"Elevated Push-Up",
"Flat Bench Press",
"Incline Alternating Dumbbell Bench Press",
"Incline Barbell Bench Press",
"Incline Bench Press",
"Incline Dumbbell Bench Press",
"Incline Hammer Dumbbell Bench Press",
"Incline Single-Arm Dumbbell Bench Press",
"Incline Smith Machine Bench Press",
"Incline Twisting Dumbbell Bench Press",
"Kneeling Push-Up",
"Machine Bench Press",
"Machine Vertical Bench Press",
"Medicine Ball Crossover Push-Up",
"Push-Up",
"Single-Arm Dumbbell Bench Press",
"Smith Machine Bench Press",
"Twisting Dumbbell Bench Press",
"Wide-Grip Push-Up",
"Cable Crossover",
"Cable Fly",
"Decline Dumbbell Fly",
"Dumbbell Fly",
"High Cable Crossover",
"Incline Cable Fly",
"Incline Dumbbell Fly",
"Incline Twisting Dumbbell Fly",
"Low Cable Crossover",
"Pec Deck",
"Pec Deck Fly",
"Bent-Knee Single-Leg Hip Lift",
"Elevated Hip Lift",
"Elevated Single-Leg Hip Lift",
"Hip Lift",
"Single-Leg Hip Lift",
"Deadlift",
"Leg Curl",
"Lying Alternating Leg Curl",
"Lying Leg Curl",
"Lying Single-Leg Curl",
"Seated Leg Curl",
"Barbell Diagonal Lunge",
"Barbell Hack Squat",
"Barbell Lunge",
"Barbell Reverse Lunge",
"Barbell Side Lunge",
"Barbell Split Squat",
"Barbell Squat",
"Barbell Step-Up",
"Barbell Walking Lunge",
"Diagonal Lunge",
"Dumbbell Diagonal Lunge",
"Dumbbell Lunge",
"Dumbbell Reverse Lunge",
"Dumbbell Side Lunge",
"Dumbbell Split Squat",
"Dumbbell Squat",
"Dumbbell Step-Up",
"Dumbbell Walking Lunge",
"Forward Lunge",
"Lateral Barbell Squat",
"Lateral Barbell Step-Up",
"Lateral Squat",
"Lateral Step-Up",
"Leg Press",
"Lunge",
"Lying Machine Squat",
"Machine Hack Squat",
"Reverse Lunge",
"Single-Arm Barbell Side Squat",
"Single-Arm Dumbbell Side Squat",
"Single-Leg Barbell Squat",
"Single-Leg Box Squat",
"Single-Leg Dumbbell Box Squat",
"Single-Leg Dumbbell Squat",
"Single-Leg Squat",
"Smith Machine Squat",
"Split Squat",
"Step-Up",
"Walking Lunge",
"Alternating Leg Extension",
"Leg Extension",
"Single-Leg Extension",
"Alternating Superman",
"Back Raise",
"Quadruped Alternating Superman",
"Superman",
"Superman Hold",
"Arnold Dumbbell Press",
"Barbell Shoulder Press",
"Dumbbell Alternating Shoulder Press",
"Dumbbell Front Raise",
"Dumbbell Shoulder Press",
"Dumbbell Twisting Shoulder Press",
"Machine Shoulder Press",
"Seated Dumbbell Rear Delt Elbow Raise",
"Single-Arm Dumbbell Shoulder Press",
"Smith Machine Shoulder Press",
"Barbell Front Raise",
"Bent-Over Cable Rear Delt Raise",
"Bent-Over Dumbbell Rear Delt Raise",
"Cable Front Raise",
"Cable Lateral Raise",
"Dumbbell Lateral Raise",
"Front Plate Raise",
"Kneeling Single-Arm Cable Rear Delt Raise",
"Lying Dumbbell External Rotation",
"Lying Dumbbell Rear Delt Raise",
"Lying Single-Arm Dumbbell Rear Delt Raise",
"Pec Deck Real Delt Extensions",
"Reverse Incline Dumbbell Rear Delt Raise",
"Seated Dumbbell Rear Delt Raise",
"Single-Arm Cable Lateral Raise",
"Cable External Rotation",
"Close-Grip Bench Press",
"Forward Lean Dips",
"Assisted Dips",
"Bench Dips",
"Diamond Push-Up",
"Dips",
"Machine Dips",
"Decline Dumbbell Triceps Extension",
"Decline EZ-Bar Tricep Extension",
"Decline Single Dumbbell Triceps Extension",
"Decline Single-Arm Dumbbell Triceps Extension",
"Dumbbell Kickback",
"Incline EZ-Bar Tricep Extension",
"Kneeling Cable Triceps Extension",
"Leaning Overhead Tricep Extension",
"Low Cable Triceps Extension",
"Lying Cable Triceps Extension",
"Lying EZ-Bar Triceps Extension",
"Lying Overhead EZ-Bar Tricep Extension",
"Lying Reverse EZ-Bar Triceps Extension",
"Lying Single Dumbbell Triceps Extension",
"Lying Single-Arm Dumbbell Triceps Extension",
"Lying Tricep Extensions",
"Overhead Dumbbell Triceps Extension",
"Overhead EZ-Bar Triceps Extension",
"Overhead Rope Cable Tricep Extension",
"Overhead Single Dumbbell Tricep Extension",
"Overhead Single-Arm Cable Tricep Extension",
"Overhead Single-Arm Dumbbell Tricep Extension",
"Reverse Tricep Pushdown",
"Rope Triceps Pushdown",
"Single-Arm Towel Triceps Pushdown",
"Single-Arm Triceps Pushdown",
"Towel Triceps Pushdown",
"Tricep Extensions",
"Tricep Pushdown",
"V-Bar Tricep Pushdown"
]

exercise_dict = {i + 1: exercise_names[i] for i in range(len(exercise_names))}
id_dict = {v: k for k, v in exercise_dict.items()}

# Print the exercise dictionary

@views.errorhandler(500)
def internal_server_error(e):
    return jsonify({'error': 'Internal Server Error'}), 500

def createGraphData(dataToAnalyze,exercise):
    dateArray = []
    repArray = []
    weightArray = []

    for item in dataToAnalyze['data']:
        dateString = item['created_at']
        parsedDate = datetime.strptime(dateString, "%Y-%m-%dT%H:%M:%S.%f%z")
        trimmedDate = parsedDate.strftime("%Y-%m-%d")
        dateArray.append(trimmedDate)

       

    for item in dataToAnalyze['data']:
        reps = item['reps']
        
        repArray.append(reps)

  

    for item in dataToAnalyze['data']:
        weight = item['weight']
        
        weightArray.append(weight)

   

    JSONdata = {
        'exercise': exercise,
        'dates': dateArray,
        'reps': repArray,
        'weights': weightArray

    }

    jsonify(JSONdata)

    return JSONdata


def fetchSingleCreatedFolder(username, folderName):
    
    response = supabase.table("userFolders").select("*").eq('user', username).eq('folderName', folderName).execute()

    data = response['data']
 
    userFolder = []
    exerciseNames = []
    exerciseIDs = data[0].get('exerciseIDs', [])


    for item in exerciseIDs:
            print(item)
            trueName = exercise_dict.get(item, "null")
            print(trueName)
            if trueName:
                exerciseNames.append(trueName)  
            else:
                exerciseNames.append("null")

    infoDict = {"folderName": folderName, "exercises": exerciseNames}
    
    userFolder.append(infoDict)
    return userFolder

def fetchUserCreatedFolders(username):
    Data = supabase.table('userFolders').select('*').eq('user', username).execute()
    print("USER FOLDER")
    print("FETCH DATA")
    print(Data)

    userFolderData = []
    

    for item in Data['data']:
        exerciseNames = []
        folderName = item.get('folderName')
        exerciseIDs = item.get('exerciseIDs')

        for item in exerciseIDs:
            exerciseNames.append(exercise_dict.get(item, "null"))
        
        infoDict = {"folderName": folderName, "exercises": exerciseNames}
        userFolderData.append(infoDict)
    return userFolderData

def fetchAllUserSets(username):
    Data = supabase.table('userSets').select('*').eq('user', username).execute()


    exerciseData = []
    
    for item in Data['data']:
        reps = item.get('reps')
        weight = item.get('weight')
        exerciseID = item.get('exerciseID')
        date = item.get('created_at')

        exerciseName = exercise_dict.get(exerciseID, "null")
        
        infoDict = {"reps": reps, "weight": weight, "exercise": exerciseName, "date": date}

        exerciseData.append(infoDict)
    
    print(exerciseData)
    return exerciseData


def fetchAllExercisesFolder(username):
    exercise_ids = set()

    data = supabase.table('userSets').select('*').eq('user', username).execute()
 

    if(data['data'] == []):
        return "null"
    else:
        for item in data['data']:
            exercise_id = item.get('exerciseID')
            if exercise_id is not None:
                exercise_ids.add(exercise_id)

        idList = list(exercise_ids)


        nameList = []

        for item in idList:
            nameList.append(exercise_dict.get(item, "null"))
        return nameList


def fetchMostRecentSet(username):
    try:
        recentSet = supabase.table('userSets').select('*').eq('user', username).order("created_at.desc").limit(1).execute()
        id = recentSet['data'][0]['exerciseID']
    
        exerciseName = supabase.table("exerciseDB").select('exercise').eq("id", str(id)).execute()
        exerciseName = exerciseName['data'][0]['exercise']
        

        recentArray = [recentSet, exerciseName]
        return recentArray
    except:
        return 0


def fetchWorkoutIndex():
    return supabase.table("exerciseDB").select('exercise').execute()

def createFolder(username, folderName, ids) -> dict:
    print(ids)
    newFolder = {
        "user": username,
        "folderName": folderName,
        "exerciseIDs":ids

    
    }

    supabase.table("userFolders").insert(newFolder).execute()

def createSet( username, exerciseID, weight, reps)-> dict:
    userSet = {
         "user": username,
         "exerciseID": exerciseID,
         "weight": weight,
         "reps": reps
         
    }

    supabase.table("userSets").insert(userSet).execute()
    
    


@views.route('/')

def home():
    return render_template('index.html', user = current_user)

@views.route('/overview', methods = ['GET','POST'])
@login_required
def overview():
    username = current_user.username
    recentSetData = (fetchMostRecentSet(username))
    
    
    workoutIndex = fetchWorkoutIndex()
    
    data = request.form
    
    if request.method == "POST":
       
       exercise = request.form.get('exercise')
       exerciseID = supabase.table('exerciseDB').select('*').eq("exercise", exercise).execute()
       exerciseID = exerciseID['data'][0]['id']
       weight = request.form.get('weight')
       reps = request.form.get('reps')
       createSet( username, exerciseID, weight, reps)
       print("set logged")
      

    
    
    

    return render_template('overview.html', user = current_user, workoutList = workoutIndex, recentSetData = recentSetData )

@views.route('/overviewUpdate')
@login_required
def overviewUpdate():
    username = current_user.username
    recentSetData = (fetchMostRecentSet(username))
   
   
    return render_template('overviewUpdate.html', recentSetData = recentSetData)



@views.route('/delete_folder', methods=['DELETE'])
def delete_folder():
    print("KSSDAS")
    print(request)
    data = request.data
    data = data.decode('utf-8')
    print("printing: "+data)
    print(type(data))
    
    
    try:
        supabase.table('userFolders').delete().eq('folderName', str(data)).execute()
        return '', 204
    except:

        return '', 204
    

   




@views.route('/delete_entry', methods=['DELETE'])
def delete_entry():
    try:
            data = request.get_json()
   
            set = data['entryId']
    
            print(set)
            response = supabase.table('userSets').delete().eq('created_at', set).execute()
    except Exception as e:
        return jsonify({'error': str(e)}), 200
   


    return jsonify({'message': 'Entry deleted successfully'}), 200

@views.route('/updateFolders')
@login_required
def updateFolders():
    username = current_user.username
    userFolders = fetchUserCreatedFolders(username)

    return render_template('userFolderUpdate.html',  userFolders = userFolders)

@views.route('/userExercises')
@login_required
def userExercises():
    username = current_user.username
    #allUniqueExerciseIDs = (fetchAllExercisesFolder(username))
    workoutIndex = fetchWorkoutIndex()
    #setData = fetchAllUserSets(username)
    #setData.reverse()
    #print("HERE IS THE SET DATA")
    #print(setData)
    #userFolders = fetchUserCreatedFolders(username)
  

    return render_template('userExercises.html', user = current_user, workoutList = workoutIndex)


@views.route('/getNewFolder', methods=['POST'])
@login_required
def getNewFolder():
    data = request.json
    
    print("CEHCK IT OUT")
    
    folderName = data["folderName"]
    print("folderName"+folderName)
    exerciseName = data["itemsData"]
    print(exerciseName)
    response = supabase.table('userFolders').select('*').eq('folderName', folderName).execute()
    if len(response['data']) == 0:

        print(response)
        ids = []
    
        for item in exerciseName:
             checkData = id_dict.get(item)
             ids.append(checkData)

    
  
        username = current_user.username
        createFolder(username, folderName, ids)

        return "Worked"
    else:

        return "2 folders cannot have the same name"


@views.route('/analytics', methods = ['POST','GET'])
@login_required
def analytics():
    username = current_user.username
    selectList = (fetchAllExercisesFolder(username))
    print(selectList)
    return render_template("analytics.html", selectList = selectList )






@views.route('/analyticsGraphLoad', methods = ['POST', 'GET'])
@login_required
def analyticsGraphLoad():
    username = current_user.username
    data = request.json
    
    exercise = data.get('selectedValue')
    

    response = supabase.table('exerciseDB').select().eq('exercise',str(exercise)).execute()

    exerciseID = response['data'][0]['id']
    
    dataToAnalyze = supabase.table('userSets').select().eq("user", str(username)).eq("exerciseID", str(exerciseID)).execute()
    

    
    JSONResponse = createGraphData(dataToAnalyze, exercise)
    
    session['JSONResponse'] = JSONResponse
    print(JSONResponse)
    return '', 204

@views.route('/analyticsGraphRender', methods = ['POST', 'GET'])
@login_required
def analyticsGraphRender():
    JSONResponse = session.get('JSONResponse')
    return render_template("analyticsGraph.html", data = JSONResponse)

@views.route('/addSet', methods = ['POST'])
@login_required
def addSet():
    username = current_user.username
    if request.method == "POST":
       
       exercise = request.form.get('exercise')
       exerciseID = id_dict.get(exercise)
       print(exercise)
       print(exerciseID)
       weight = request.form.get('weight')
       reps = request.form.get('reps')
       createSet( username, exerciseID, weight, reps)
       print("set logged")

    return '', 204



@views.route('/appendFolder', methods = ['POST'])
@login_required
def appendFolder():
    data = request.form
    username = current_user.username

    if request.method == "POST":
        folderName = request.form.get('folderName')
        exercises = request.form.get('exercises')
        print(folderName)
        print(exercises)
        

        #exerciseID = supabase.table('userFolders').select('*').eq("exercise", exercise).execute()
        #exerciseID = exerciseID['data'][0]['id']

       

    return '', 204

@views.route('/tools', methods = ['POST','GET'])
@login_required
def tools():


    return render_template("tools.html") 


@views.route("/updateUserSet", methods = ['POST', 'GET'])
@login_required
def updateUserSet():
    username = current_user.username
    folderName = request.args.get('folderId')
    folderName = folderName.replace('-',' ')

    userFolder = fetchSingleCreatedFolder(username, folderName)
 

    exerciseName = request.args.get('exerciseName')
    matching_folder = next((folder for folder in userFolder if folder['folderName'] == folderName), None)

    setData = fetchAllUserSets(username)
    setData.reverse()

    
    
    

    
    
    return render_template('updateUserSet.html', exerciseName = exerciseName, folderId = folderName, user = current_user, setData = setData, userFolders = matching_folder)


@views.route("/refreshAllExercises", methods = ['POST', 'GET'])
@login_required
def refreshAllExercises():
    
    folderName = request.args.get('data')
    username = current_user.username
    allUniqueExerciseIDs = (fetchAllExercisesFolder(username))
    workoutIndex = fetchWorkoutIndex()
    setData = fetchAllUserSets(username)
    setData.reverse()
    print("HERE IS THE SET DATA")
    userFolders = fetchUserCreatedFolders(username)
    return render_template('refreshAllExercises.html', folderName = folderName, user = current_user, workoutList = workoutIndex, allExercises = allUniqueExerciseIDs, setData = setData, userFolders = userFolders )



@views.route("/getExerciseAJAX", methods = ['POST', 'GET'])
@login_required
def  getExerciseAJAX():
    workoutIndex = fetchWorkoutIndex()
    username = current_user.username
    userFolders = fetchUserCreatedFolders(username)
    setData = fetchAllUserSets(username)
    setData.reverse()
    allUniqueExerciseIDs = (fetchAllExercisesFolder(username))
    if(allUniqueExerciseIDs == "null"):
        return render_template('userExerciseAJAX.html', user = current_user,workoutList = workoutIndex, userFolder = userFolders, allExercises = "")

    
    
 
    return render_template('userExerciseAJAX.html', user = current_user, workoutList = workoutIndex, allExercises = allUniqueExerciseIDs, setData = setData, userFolders = userFolders)


@views.route("/refreshUserFolderList", methods = ['POST', 'GET'])
@login_required
def  refreshUserFolderList():

    username = current_user.username
    allUniqueExerciseIDs = (fetchAllExercisesFolder(username))
    workoutIndex = fetchWorkoutIndex()
    setData = fetchAllUserSets(username)
    setData.reverse()
    print("HERE IS THE SET DATA")
    
    userFolders = fetchUserCreatedFolders(username)
   
    return render_template('refreshUserContent.html', user = current_user, workoutList = workoutIndex, setData = setData, userFolders = userFolders)