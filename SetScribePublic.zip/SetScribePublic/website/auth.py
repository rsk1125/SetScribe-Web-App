from flask import Blueprint, render_template, request, flash, redirect, url_for 
from flask_login import login_user, login_required, logout_user, current_user, UserMixin
from supabase_py import create_client, Client
from website import url, key
from werkzeug.security import generate_password_hash, check_password_hash 
from . import User

import time
supabase: Client = create_client(url,key)
auth = Blueprint('auth', __name__)




def createUser(username, password1 ,email, name, dob, experience) -> dict:
    user = {
         "username": username,
         "password": password1,
         "email": email,
         "name": name,
         "dob":dob,
         "experienceLev": experience
    }
    data = supabase.table("Users").insert(user).execute()

    return data['data']

def checkUserExists(username):
     response = supabase.table("Users").select('*').eq("username",username).execute()
     print(response)
     if not response['data']:
          print("username available")
          return 0
     else:
          print("taken")
          return 1

 

@auth.route('/login', methods = ['GET','POST'])

def login():
    data = request.form
    print(data)
    if request.method == "POST":
        username = request.form.get('username')
        password = request.form.get('password')
        result = (supabase.table("Users").select('*').eq("username", username).execute())
        print(result) 
        
        requestedUsername = result['data'][0]['username']
        if requestedUsername == username:
                    print("Yes")
                    if check_password_hash(result['data'][0]['password'], password):
                         print("passwords match")
                         user = User(id=result['data'][0]['id'], username=result['data'][0]['username'], email=result['data'][0]['email'], password=result['data'][0]['password'])
                         print(user.username)
                         
                              
                              
                         flash("Login Successful", category = "loginSuccess")
                         login_user(user, remember=True)
                         return redirect(url_for('views.overview'))

                    else:   
                        flash("Your username or password is incorrect", category = "loginError")
           
    
    return render_template('login.html')

@auth.route('/logout')
@login_required

def logout():
     logout_user()
     return redirect(url_for('auth.login'))

@auth.route('/sign-up', methods = ['GET','POST'])




def signup():
    data = request.form
    print(data)
    if request.method == "POST":
        email = request.form.get('email')
        print("hello")
        print(email)
        username = request.form.get('username')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        name = request.form.get('name')
        dob = request.form.get('date-of-birth')
        experience = request.form.get('experience-level')
         
     

        if (password1 != password2):
            flash("Passwords must match", category = "error")

        elif ((len(password1) or len(password2)) < 7):
             flash("Password must be greater than 6 characters", category = "error")

        elif ('@' and '.') not in (str(email)):
             flash("Please enter a valid e-mail", category = "error")

        elif len(username) < 4:
             flash("Username must be 4 characters or longer", category = "error")

        
        elif(checkUserExists(username) == 1):
             flash("Username already in use", category = "error")

        elif len(name) < 3:
             flash("Name must be 3 characters or longer", category = "error")
          
        else:
             
             createUser(username,generate_password_hash(password1, method="sha256"),email, name, dob, experience)
             
             flash("Account Created", category = "success")
             time.sleep(1.5)
             return redirect(url_for('auth.login'))
             

    return render_template('signup.html')
  
